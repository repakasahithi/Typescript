// Hello World App

// Variables Creation in TypeScript


